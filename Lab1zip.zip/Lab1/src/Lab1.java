import java.util.Arrays;
import java.util.Scanner;

public class Lab1 {

	public static boolean Rotation(String s1, String s2) {
// The first thing to check is whether the two strings are of the same length. 
		if (s1.length() != s2.length()) 
			
// If the strings are of different lengths, then the the two strings are not rotations of each other.
			  
			return false;
        
      //Concatenate one of the strings to itself.
        String concatenatedString = s1 + s1;
        return concatenatedString.contains(s2);
    }
	// main method
	public static void main(String[] args){
		  // create an object of Scanner class, will help take in the user input
		Scanner sc = new Scanner(System.in);
		
		// This takes the input from users
		  System.out.print("Enter first string: ");
		    String s1 = sc.nextLine();
		    System.out.print("Enter second string: ");
		    String s2 = sc.nextLine();
		  //Check if s2 is located in the concatenated version of s1  
	     boolean R = Rotation(s1, s2);
	     if(R) System.out.println(s1 + " and " + s2 + " are rotations of each other");
	     else System.out.println(s1 + " and " + s2 + " are not rotations of each other");	
	    
	     
	     // create an object of Scanner class, will help take in the user input
	    Scanner an = new Scanner(System.in);

	    // This takes the input from users
	    System.out.print("Enter first phrase: ");
	    String str1 = an.nextLine();
	    System.out.print("Enter second phrase: ");
	    String str2 = an.nextLine();

	    // This checks if the length is same
	    if(str1.length() == str2.length()) {

	      // This converts the strings to a char array
	      char[] charArray1 = str1.toCharArray();
	      char[] charArray2 = str2.toCharArray();

	      // sort the char array
	      Arrays.sort(charArray1);
	      Arrays.sort(charArray2);

	      // if the sorted char arrays are same then the string is an anagram
	      boolean result = Arrays.equals(charArray1, charArray2);

	      if(result) {
	        System.out.println(str1 + " and " + str2 + " are anagrams of each other.");
	      }
	      else {
	        System.out.println(str1 + " and " + str2 + " are not anagrams of each other.");
	      }
	    }
	    else {
	      System.out.println(str1 + " and " + str2 + " are not anagrams of each other.");
	    }

	    an.close();
	  }
	 
	    }







	 